function masker_shadow = plshadow( data_nir,data_swir,data_clear_land,masker_observation,percent_low,...
    sun_zenith_deg,sun_azimuth_deg, slope_data,aspect_data,dim)
% get potential layer
%% SCS+C for topo correct...
data_nir=getDataTopoCorrected(data_nir,data_clear_land,sun_zenith_deg,sun_azimuth_deg, slope_data,aspect_data );
data_swir=getDataTopoCorrected(data_swir,data_clear_land,sun_zenith_deg,sun_azimuth_deg, slope_data,aspect_data );

 %% band 4 flood fill
    % estimating background (land) Band 4 ref
    backg_b4=prctile(data_nir(data_clear_land),100*percent_low);
    data_nir(masker_observation==0)=backg_b4;
    % fill in regional minimum Band 4 ref
    data_nir_filled=imfill(data_nir);
    data_nir_dif=data_nir_filled-data_nir;

    %% band 5 flood fill
    % estimating background (land) Band 4 ref
    backg_b5=prctile(data_swir(data_clear_land),100*percent_low);
    data_swir(masker_observation==0)=backg_b5;
    % fill in regional minimum Band 5 ref
    data_swir_filled=imfill(data_swir);
    data_swir_dif=data_swir_filled-data_swir;
    
    %% compute shadow probability
    shadow_prob=min(data_nir_dif,data_swir_dif);
    % get potential cloud shadow
    
    masker_shadow=zeros(dim,'uint8'); % shadow mask
    masker_shadow(shadow_prob>200)=1;
    masker_shadow(masker_observation==0)=255;
end
function data_corected = getDataTopoCorrected(data_ori,index_exclude_cloud_water,sun_zenith_deg,sun_azimuth_deg, slope_data,aspect_data )
    sun_zenith_rad=deg2rad(sun_zenith_deg);
    sun_zenith_cos=cos(sun_zenith_rad);
    sun_zenith_sin=sin(sun_zenith_rad);
    cos_sita=sun_zenith_cos.*cos(deg2rad(slope_data))+sun_zenith_sin.*sin(deg2rad(slope_data)).*cos(deg2rad(sun_azimuth_deg-aspect_data));
    cos_sita_exclude_cloud=cos_sita(index_exclude_cloud_water);
    data_exclude_cloud=data_ori(index_exclude_cloud_water);
    c_fitted=polyfit(double(cos_sita_exclude_cloud),double(data_exclude_cloud),1);
    c=c_fitted(1,2)/c_fitted(1,1);
    data_corected=double(data_ori).*(cos(deg2rad(slope_data)).*sun_zenith_cos+c)./(cos_sita+c);
%     reflectance_corrected=round(re_corected);
end

