function [ c,RMSE] = lapseRateFit( elevation_lst,temp_lst )
%LAPSERATEFIT Summary of this function goes here
%   Detailed explanation goes here
    c0 = [1 1]; % Starting guess
%     lb=[];
%     ub=[];
%     options=optimset('Display','none');
    opts=statset('nlinfit');
    opts.RobustWgtFun='bisquare'; 
    opts.Robust='on';
    [c,Rr,Jj,CovB,MSE] = nlinfit(elevation_lst,temp_lst,@lapseRateModel,c0,opts);
    RMSE=sqrt(MSE);

%     [c,resnorm] = lsqcurvefit(@lapseRateModel,c0,elevation_lst,temp_lst,lb,ub,options);
end
