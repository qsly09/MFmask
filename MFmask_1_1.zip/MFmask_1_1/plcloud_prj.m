function [data_reshaped_cs,data_boundary_prj] = plcloud_prj( shadow_ori_object,data_boundary,sun_zenith_deg,...
    sun_azimuth_deg,dem,dem_base,dim)
    data_reshaped_cs=zeros(dim,'single');
     % get track derection
    [rows,cols]=find(data_boundary==1);
    [cor_ul_y,num]=min(rows);cor_ul_x=cols(num);
    [cor_lr_y,num]=max(rows);cor_lr_x=cols(num);
    [cor_ll_x,num]=min(cols);cor_ll_y=rows(num);
    [cor_ur_x,num]=max(cols);cor_ur_y=rows(num);
    % get view angle geometry
    [A,B,C,omiga_par,omiga_per]=getSensorViewGeo(cor_ul_x,cor_ul_y,cor_ur_x,cor_ur_y,cor_ll_x,cor_ll_y,cor_lr_x,cor_lr_y); 
    clear cor_ul_x cor_ul_y cor_ur_x cor_ur_y cor_ll_x cor_ll_y cor_lr_x cor_lr_y;
    %% Read data ��ȡ����
    % Matrix used in recording the x,y
    [xys_x,xys_y]=find(shadow_ori_object>0);
    count_pixel_cs=size(xys_x,1);
    fprintf('Projecting all potential cloud objects. This might take a couple of minutes (sometimes more than 20 min) so be patient.\n');
    for i=1: count_pixel_cs
        % corrected for view angle xys
        xys_tmp=zeros(1,2);
        dem_cur=dem(xys_x(i,1),xys_y(i,1))-dem_base;
        [xys_tmp(1),xys_tmp(2)]=getRealCloudPosition(xys_y(i,1),...
                    xys_x(i,1),dem_cur,A,B,C,omiga_par,omiga_per);
        [ dX,dY ] = projectDirection( sun_azimuth_deg,sun_zenith_deg,dem_cur);

        Yprojected=round(xys_tmp(1)+dY/30);
        Xprojected=round(xys_tmp(2)+dX/30);
        
        recorder=shadow_ori_object(xys_x(i,1),xys_y(i,1));

        if Xprojected> 0&&Yprojected>0&&Xprojected< dim(1)&&Yprojected<dim(2)
             data_reshaped_cs(Xprojected,Yprojected)=recorder;
        end
    end
    clear shadow_ori_object recorder count_pixel_cs xys_x xys_y;
    data_reshaped_cs_gaps=zeros(dim);
    for ii=2:dim(1)-1
        for jj=2:dim(2)-1
            if data_reshaped_cs(ii,jj)==0
                neighber=data_reshaped_cs(ii-1:ii+1,jj-1:jj+1);
                neighber_sum=sum(neighber(:));
                neighber=neighber>0;
                neighber_num=sum(neighber(:));
                if neighber_num>=5
                    data_reshaped_cs_gaps(ii,jj)=neighber_sum/neighber_num;
                end
            end
        end
    end
    data_reshaped_cs=data_reshaped_cs+data_reshaped_cs_gaps;
    clear data_reshaped_cs_gaps neighber_sum neighber_num;  
    
    
    [rows,cols]=find(data_boundary==0);
    clear data_boundary;
    data_boundary_prj1=zeros(dim,'uint8');
    count_pixel_boundary=size(rows,1);
    for i=1: count_pixel_boundary
        xys_tmp=zeros(1,2);
        dem_cur=dem(rows(i,1),cols(i,1))-dem_base;
        [xys_tmp(1),xys_tmp(2)]=getRealCloudPosition(cols(i,1),...
                    rows(i,1),dem_cur,A,B,C,omiga_par,omiga_per);
        [ dX,dY ] = projectDirection( sun_azimuth_deg,sun_zenith_deg,dem_cur);
        Yprojected=round(xys_tmp(1)+dY/30);
        Xprojected=round(xys_tmp(2)+dX/30);
        if Xprojected> 0&&Yprojected>0&&Xprojected< dim(1)&&Yprojected<dim(2)
             data_boundary_prj1(Xprojected,Yprojected)=1;
        end
    end
    data_boundary_prj1=bwmorph(data_boundary_prj1,'majority');
    data_boundary_prj=zeros(dim,'uint8');
    data_boundary_prj(data_boundary_prj1==0)=1;
end