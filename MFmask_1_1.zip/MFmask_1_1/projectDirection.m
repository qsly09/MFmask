function [ dX,dY ] = projectDirection( solarAzimuth,solarZenith,height)
% solarAzimuth ̫����λ��
% solarZenith ̫���춥��
% height �߶�
% Xoriginal ԭʼX���꣨ͼ�����꣩
% Yoriginal ԭʼY���꣨ͼ�����꣩
    dX=0;
    dY=0;
    sun_elevation_deg=90-solarZenith;
    sun_elevation_rad=deg2rad(sun_elevation_deg);
    
    Sun_tazi=solarAzimuth-90;
    sun_tazi_rad=deg2rad(Sun_tazi);
    % moved distance (pixel)
    i_xy=height/tan(sun_elevation_rad);
    
    if solarAzimuth< 180
        dX=0-i_xy*sin(sun_tazi_rad); 
        dY=0-i_xy*cos(sun_tazi_rad); 
    else
        dX=i_xy*sin(sun_tazi_rad);
        dY=i_xy*cos(sun_tazi_rad);
    end
end
    
% % %     
% % %     dHoriz=abs(tan(solarZenith*pi/180)*height);
% % %     switch solarAzimuth
% % %         case 0 
% % %             dY=0-dHoriz;
% % %         case 90 
% % %             dX=0-dHoriz;
% % %         case 180 
% % %             dY=dHoriz;
% % %         case 270 
% % %             dX=dHoriz;
% % %         case 360 
% % %             dY=0-dHoriz;
% % %         otherwise
% % %             if (0<solarAzimuth)&&(solarAzimuth<90)
% % %                 curAz=solarAzimuth*pi/180;
% % %                 dX=abs(cos(curAz)*dHoriz);
% % %                 dX=dX;
% % %                 dY=abs(sin(curAz)*dHoriz);
% % %                 dY=0-dY;
% % %                 return;
% % %             end
% % %             
% % %             if (90<solarAzimuth)&&(solarAzimuth<180)
% % %                 curAz=(solarAzimuth-90)*pi/180;
% % %                 dX=abs(sin(curAz)*dHoriz);
% % %                 dX=0-dX;
% % %                 dY=abs(cos(curAz)*dHoriz);
% % %                 dY=0-dY;
% % %                 return;
% % %             end
% % %             
% % %             if (180<solarAzimuth)&&(solarAzimuth<270)
% % %                 curAz=(solarAzimuth-180)*pi/180;
% % %                 dX=abs(sin(curAz)*dHoriz);
% % %                 dX=dX;
% % %                 dY=abs(cos(curAz)*dHoriz);
% % %                 dY=0-dY;
% % %                 return;
% % %             end
% % %             
% % %             if (270<solarAzimuth)&&(solarAzimuth<360)
% % %                 curAz=(solarAzimuth-270)*pi/180;
% % %                 dX=abs(cos(curAz)*dHoriz);
% % %                 dX=dX;
% % %                 dY=abs(sin(curAz)*dHoriz);
% % %                 dY=dY;
% % %                 return;
% % %             end
% % %     end
% % % end

