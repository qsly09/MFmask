function clr_pct = MFmask(fullfile_path,im,cldpix,sdpix,snpix,cldprob,num_Lst,num_near,gap_off)

    [zen,azi,ptm,Temp,t_templ,t_temph,Water,Snow,pCloud,pShadow,....
        dem,dem_b,dim,mask,ul,resolu,zc]...
        =plcloud_ratelapse(fullfile_path,im,cldprob,num_Lst);

    [dX,dY]= projectPixel(dim,mask,dem,dem_b,zen,azi);
    
    [similar_num,cloud_cal, shadow_cal]=matchC2PCS_plane(pCloud,pShadow,...
        dX,dY,...
        dem ,Temp,t_templ,t_temph,zen,...
        azi,dim,ptm,dem_b,num_near,gap_off);

    % dialte shadow first
    SEs=strel('square',2*cldpix+1);
    shadow_cal=imdilate(shadow_cal,SEs);
    % dialte cloud first
    SEc=strel('square',2*sdpix+1);
    cloud_cal=imdilate(cloud_cal,SEc);

    cs_final=zeros(dim,'uint8');
    cs_final(Water==1)=1;
    % mask from plcloud
    % step 1 snow or unknow
    cs_final(Snow==1)=3; % snow
    % step 2 shadow above snow and everyting
    cs_final(shadow_cal==1)=2; %shadow
    % step 3 cloud above all
    cs_final(cloud_cal==1)=4; % cloud
    cs_final(mask==0)=255;
    norln=strread(im,'%s','delimiter','.'); 
    n_name=char(norln(1));
%     enviwrite([fullfile_path,n_name,'_MFmask'],cs_final,'uint8',resolu,ul,'bsq',zc);
    imwrite(cs_final,[fullfile_path,n_name,'_MFmask_pap_nn_',num2str(num_near),'.tif'],'tif');
    % record clear pixel percent;
    tmpcs = cs_final <= 1;
    clr_pct = 100*sum(tmpcs(:))/sum(mask(:));
    fprintf('Fmask finished for %s with %.2f%% clear pixels\n',im,clr_pct);
    % toc
end