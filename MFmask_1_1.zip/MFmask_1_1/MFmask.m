function clr_pct = MFmask(fullfile_path,im,cldpix,sdpix,snpix,cldprob,num_Lst,num_near,gap_off)

[zen,azi,ptm,Temp,t_templ,t_temph,Water,Snow,Cloud,Shadow,....
    shadow_prj,recdRowOri,recdCowOri,dem,dem_b,dim,ul,resolu,zc]...
    =plcloud_ratelapse(fullfile_path,im,cldprob,num_Lst);

    [similar_num,cloud_cal, data_shadow_matched]=matchC2PCS_plane(Cloud,Snow,shadow_prj,dem ,Temp,t_templ,t_temph,zen,...
    azi,dim,ptm,dem_b,num_near,gap_off);

    fprintf('Converting projeced cloud shadow into cloud shadow in imagery. This might take some minutes so be patient.\n');
    shadow_cal=zeros(dim,'uint8'); 
    if similar_num==-1
        shadow_cal(cloud_cal==false)=1;
    else
        for i=1:dim(1)
            for j=1:dim(2)
                if(data_shadow_matched(i,j)>0)
                     for b=1:3
                        curRow=recdRowOri(i,j,b);
                        curCow=recdCowOri(i,j,b);
                        if curRow>0&&curCow>0&&(Shadow(curRow,curCow)==1||Cloud(curRow,curCow)==1)
                            shadow_cal(curRow,curCow)=1; 
                        end
                    end
                end
            end
        end
    end
    % dialte shadow first
    SEs=strel('square',2*sdpix+1);
    shadow_cal=imdilate(shadow_cal,SEs);

    % dialte cloud
    SEc=strel('square',2*cldpix+1);
    cloud_cal=imdilate(cloud_cal,SEc);
    
    boundary_test=Cloud<255;
    cs_final=zeros(dim,'uint8');
    cs_final(Water==1)=1;
    % mask from plcloud
    % step 1 snow or unknow
    cs_final(Snow==1)=3; % snow
    % step 2 shadow above snow and everyting
    cs_final(shadow_cal==1)=2; %shadow
    % step 3 cloud above all
    cs_final(cloud_cal==1)=4; % cloud
    cs_final(boundary_test==0)=255;
    norln=strread(im,'%s','delimiter','.'); 
    n_name=char(norln(1));
%     enviwrite([fullfile_path,n_name,'_MFmask'],cs_final,'uint8',resolu,ul,'bsq',zc);
    imwrite(cs_final,[fullfile_path,n_name,'_MFmask_9_23.tif'],'tif');
    % record clear pixel percent;
    tmpcs = cs_final <= 1;
    clr_pct = 100*sum(tmpcs(:))/sum(boundary_test(:));
    fprintf('Fmask finished for %s with %.2f%% clear pixels\n',im,clr_pct);
    % toc
end