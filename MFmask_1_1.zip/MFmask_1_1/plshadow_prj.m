function [shadow_ori,data_reshaped_cs,recorderRowOriginalImage,recorderCowOriginalImage]...
    = plshadow_prj( data_nir,data_swir,data_clear_land,masker_observation,percent_low,...
    final_cld,sun_zenith_deg,sun_azimuth_deg, slope_data,aspect_data,...
    dem,dem_base,dim)

%% get ori shadow layer.
    fprintf('Calculating potential cloud shadow pixels. This might take some minutes so be patient.\n');
    shadow_ori=plshadow( data_nir,data_swir,data_clear_land,masker_observation,percent_low,...
        sun_zenith_deg,sun_azimuth_deg, slope_data,aspect_data,dim);
    shadow_ori=shadow_ori&~final_cld;
    clear final_cld slope_data aspect_data data_clear_land data_nir data_swir percent_low;
    
    data_reshaped_cs=zeros(dim,'uint8');
    recorderRowOriginalImage=zeros(dim(1),dim(2),3);
    recorderCowOriginalImage=zeros(dim(1),dim(2),3);
    %% Read data ��ȡ����
    % Matrix used in recording the x,y
    [xys_x,xys_y]=find(shadow_ori==1);
    count_pixel_cs=size(xys_x,1);
     % get track derection
    [rows,cols]=find(masker_observation==1);
    [cor_ul_y,num]=min(rows);cor_ul_x=cols(num);
    [cor_lr_y,num]=max(rows);cor_lr_x=cols(num);
    [cor_ll_x,num]=min(cols);cor_ll_y=rows(num);
    [cor_ur_x,num]=max(cols);cor_ur_y=rows(num);
    clear masker_observation;
    % get view angle geometry
    [A,B,C,omiga_par,omiga_per]=getSensorViewGeo(cor_ul_x,cor_ul_y,cor_ur_x,cor_ur_y,cor_ll_x,cor_ll_y,cor_lr_x,cor_lr_y);
    clear cor_ul_x cor_ul_y cor_ur_x cor_ur_y cor_ll_x cor_ll_y cor_lr_x cor_lr_y;
    fprintf('Projecting all potential cloud shadow pixels. This might take a couple of minutes (sometimes more than 20 min) so be patient.\n');
    for i=1: count_pixel_cs
        xys_tmp=zeros(1,2);
        dem_cur=dem(xys_x(i,1),xys_y(i,1))-dem_base;
        [xys_tmp(1),xys_tmp(2)]=getRealCloudPosition( xys_y(i,1),...
                   xys_x(i,1),dem_cur,A,B,C,omiga_par,omiga_per);
        [ dX,dY ] = projectDirection( sun_azimuth_deg,sun_zenith_deg,dem_cur);
        Yprojected=round(xys_tmp(1)+dY/30);
        Xprojected=round(xys_tmp(2)+dX/30);
        if Xprojected> 0&&Yprojected>0&&Xprojected< dim(1)&&Yprojected<dim(2)
             data_reshaped_cs(Xprojected,Yprojected)=1;
             for b=1:3
                 if recorderRowOriginalImage(Xprojected,Yprojected,b)>0
                    continue;
                 end
                 recorderRowOriginalImage(Xprojected,Yprojected,b)=xys_x(i,1);
                 recorderCowOriginalImage(Xprojected,Yprojected,b)=xys_y(i,1);
                 break;
             end
        end
    end
    clear Xprojected Yprojected xys_tmp count_pixel_cs dem_cur xys_x xys_y;
    
    data_reshaped_cs_gaps=bwmorph(data_reshaped_cs,'majority');
    data_reshaped_cs(data_reshaped_cs_gaps==1)=1;
    
%     data_reshaped_cs_gaps=zeros(dim,'uint8');
%     for ii=2:dim(1)-1
%         for jj=2:dim(2)-1
%             if data_reshaped_cs(ii,jj)==0
%                 neighber=data_reshaped_cs(ii-1:ii+1,jj-1:jj+1);
%%                  neighber=neighber>0;
%                 neighber_num=sum(neighber(:));
%                 if neighber_num>=5
%                     data_reshaped_cs_gaps(ii,jj)=1;
%                 end
%             end
%         end
%     end
%     data_reshaped_cs(data_reshaped_cs_gaps==1)=1; 
end

function masker_shadow = plshadow( data_nir,data_swir,data_clear_land,masker_observation,percent_low,...
    sun_zenith_deg,sun_azimuth_deg, slope_data,aspect_data,dim)
% get potential layer
%% SCS+C for topo correct...
data_nir=getDataTopoCorrected(data_nir,data_clear_land,sun_zenith_deg,sun_azimuth_deg, slope_data,aspect_data );
data_swir=getDataTopoCorrected(data_swir,data_clear_land,sun_zenith_deg,sun_azimuth_deg, slope_data,aspect_data );

 %% band 4 flood fill
    % estimating background (land) Band 4 ref
    backg_b4=prctile(data_nir(data_clear_land),100*percent_low);
    data_nir(masker_observation==0)=backg_b4;
    % fill in regional minimum Band 4 ref
    data_nir_filled=imfill(data_nir);
    data_nir_dif=data_nir_filled-data_nir;

    %% band 5 flood fill
    % estimating background (land) Band 4 ref
    backg_b5=prctile(data_swir(data_clear_land),100*percent_low);
    data_swir(masker_observation==0)=backg_b5;
    % fill in regional minimum Band 5 ref
    data_swir_filled=imfill(data_swir);
    data_swir_dif=data_swir_filled-data_swir;
    
    %% compute shadow probability
    shadow_prob=min(data_nir_dif,data_swir_dif);
    % get potential cloud shadow
    
    masker_shadow=zeros(dim,'uint8'); % shadow mask
    masker_shadow(shadow_prob>200)=1;
    masker_shadow(masker_observation==0)=255;
end
function data_corected = getDataTopoCorrected(data_ori,index_exclude_cloud_water,sun_zenith_deg,sun_azimuth_deg, slope_data,aspect_data )
    sun_zenith_rad=deg2rad(sun_zenith_deg);
    sun_zenith_cos=cos(sun_zenith_rad);
    sun_zenith_sin=sin(sun_zenith_rad);
    cos_sita=sun_zenith_cos.*cos(deg2rad(slope_data))+sun_zenith_sin.*sin(deg2rad(slope_data)).*cos(deg2rad(sun_azimuth_deg-aspect_data));
    cos_sita_exclude_cloud=cos_sita(index_exclude_cloud_water);
    data_exclude_cloud=data_ori(index_exclude_cloud_water);
    c_fitted=polyfit(double(cos_sita_exclude_cloud),double(data_exclude_cloud),1);
    c=c_fitted(1,2)/c_fitted(1,1);
    data_corected=double(data_ori).*(cos(deg2rad(slope_data)).*sun_zenith_cos+c)./(cos_sita+c);
%     reflectance_corrected=round(re_corected);
end
