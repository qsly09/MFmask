function temp_p = lapseRateModel( c,elevation )
%% tp=c0+c1*elevation+c3
    temp_p=c(1)+c(2).*elevation;
%     temp_p=c(1).*elevation.^2+c(2).*elevation+c(3);
end

