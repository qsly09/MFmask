function clr_pct = MFmaskBatch(cldpix,sdpix,snpix,cldprob)
% % % jm=findResource('scheduler','type','jobManager','LookupURL','192.168.100.100');
% % % matlabpool(jm,'FileDependencies','MFmaskBatch.m');
% % % matlabpoolsize=matlabpool('size');
%record_base_h_near
fprintf('MFmask batch starts ...\n');
filepath_work='I:\Data\Cloud Cover Assessment Validation Data Mountains\Landsat test for MFask';
subdir  = dir( filepath_work );
num_files=length( subdir );

% parfor 
for i = 1 : num_files
    if( isequal( subdir( i ).name, '.' )||...
        isequal( subdir( i ).name, '..')||...
        ~subdir( i ).isdir) % �������Ŀ¼������
        continue;
    end
    
    s=sprintf('��%f1������%f2��',i-2,num_files-2);
    disp(s);
%    subdir_path_mtl = fullfile( filepath_work, subdir( i ).name, subdir( i ).name, 'L*MTL.txt' );
    subdir_path_mtl = fullfile( filepath_work, subdir( i ).name, 'L*MTL.txt' );
    norMTL=dir(subdir_path_mtl);
    existMTL=size(norMTL);

    if existMTL(1)==0
        fprintf('No L*MTL.txt header in the current folder!\n');
        continue;
    end
    fileName=norMTL.name;
    fileName
    fullfile_path=[(fullfile( filepath_work, subdir( i ).name)),'\'];
%    fullfile_path=[(fullfile( filepath_work, subdir( i ).name, subdir( i ).name)),'/'];
    fid_in=fopen([fullfile_path,norMTL.name],'r');
    geo_char=fscanf(fid_in,'%c',inf);
    fclose(fid_in);
    geo_char=geo_char';
    geo_str=strread(geo_char,'%s');

    % Identify Landsat Number (Lnum = 4, 5, 7, or 8)
    LID=char(geo_str(strmatch('SPACECRAFT_ID',geo_str)+2));
    num_Lst=str2double(LID(end-1));
%     fprintf('Cloud, cloud shadow, and snow detection for Landsat %d images\n',num_Lst); 
    DATEID=char(geo_str(strmatch('ACQUISITION_DATE',geo_str)+2));
    if isempty(DATEID)
        DATEID=char(geo_str(strmatch('DATE_ACQUIRED',geo_str)+2));
    end
    num_date=datenum(DATEID,'yyyy-mm-dd');
    num_date_gap=datenum('2003-05-31','yyyy-mm-dd');
    gap_off=0;

    % default buffering pixels for cloud, cloud shadow, and snow
    cldpix = 3;
    sdpix = 3;
    snpix = 0;
    cldprob = 22.5;
    % default cloud probability threshold for cloud detection
    if num_Lst < 8
        fprintf('Cloud probability threshold of %.2f%% (default)\n',cldprob);
        if (num_Lst==7)&&(num_date>=num_date_gap)
            gap_off=1;
        end
    elseif num_Lst == 8
        cldprob = 22.5; % the default probability threshold may change for Landsat 8
        fprintf('Cloud probability threshold of %.2f%% (default)\n',cldprob);
    else
        fprintf('Images are not from Landsat 4~8\n');
%             return;
    end
    num_near=16;
    tic
    MFmask(fullfile_path,norMTL.name,cldpix,sdpix,snpix,cldprob,num_Lst,num_near,gap_off); % newest version 3.2.1
    t=toc
end

end